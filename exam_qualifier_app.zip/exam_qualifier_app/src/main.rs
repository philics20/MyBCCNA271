use std::io::{self, Write};

fn get_score() -> f32 {
    loop {
        io::stdout().flush().expect("Failed to flush stdout");

        let mut score = String::new();
        io::stdin()
            .read_line(&mut score)
            .expect("Failed to read input");

        match score.trim().parse::<f32>() {
            Ok(num) => return num,
            Err(_) => {
                println!("Invalid input, Please enter a valid score: ");
            }
        }
    }
}

fn weighted_average_calc(test1: f32, test2: f32, assignment : f32, project : f32) -> f32 {
    (test1 * 0.30) + (test2 * 0.50) + (assignment * 0.10) + (project * 0.10)
}

fn main() {
    println!("---------Exam Qualifier---------\n");

    print!("Test 1 score in %: ");
    let test1 = get_score(); 

    print!("Test 2 score in %: ");
    let test2 = get_score();

    print!("Assignment score in %: ");
    let assignment = get_score();

    print!("Project score in %: ");
    let project = get_score();
    
    println!("\n------------Result------------\n");
    
    let avg = weighted_average_calc(test1, test2, assignment, project);
    if avg >= 50f32 {
        println!("You qualified with a weighted average of: {:.2}%\n", avg);
    } else {
        println!("You did not qualify with a weighted average of: {:.2}%\n", avg);
    }
}
